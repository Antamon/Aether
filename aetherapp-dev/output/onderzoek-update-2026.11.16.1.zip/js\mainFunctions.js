// Kleine, centrale helper om JSON van de server op te halen
// - endpoint: bv. "checkLogin.php" of "api/events/getEventList.php"
// - options: { method: 'POST', body: {...} }
async function aetherRequestJson(endpoint, options = {}) {
    const {
        method = "GET",
        body = null,
        headers = {}
    } = options;

    const fetchOptions = {
        method,
        headers: {
            ...headers
        }
    };

    if (method.toUpperCase() !== "GET" && window.AETHER_CSRF_TOKEN) {
        fetchOptions.headers["X-CSRF-Token"] = window.AETHER_CSRF_TOKEN;
    }

    if (body !== null) {
        fetchOptions.headers["Content-Type"] = "application/json";
        fetchOptions.body = JSON.stringify(body);
    }

    const response = await fetch(endpoint, fetchOptions);

    if (!response.ok) {
        // Probeer leesbare foutinfo te krijgen
        let text = "";
        try {
            text = await response.text();
        } catch (e) {
            text = "(geen body)";
        }
        const error = new Error(`API-fout ${response.status}: ${text}`);
        error.status = response.status;
        error.responseBody = text;
        throw error;
    }

    // Probeer JSON te parsen – als dat niet kan, geven we null terug
    try {
        const data = await response.json();
        if (data && typeof data.csrfToken === "string") {
            window.AETHER_CSRF_TOKEN = data.csrfToken;
        }
        return data;
    } catch (e) {
        return null;
    }
}

// Deel alleen deze leesaanvragen binnen de huidige pagina. Nooit opslag op schijf.
const aetherReadRequests = new Map();

function aetherInvalidateReadRequests() {
    aetherReadRequests.clear();
}

async function apiFetchJson(endpoint, options = {}) {
    const path = String(endpoint).split("?")[0].replace(/^\.\//, "");
    const method = String(options.method || "GET").toUpperCase();
    const isRead = method === "GET" || /^api\/[^/]+\/get[^/]*\.php$/.test(path);
    const ttl = path === "api/users/getUserList.php" && method === "GET" ? 300000
        : path === "api/characters/getCharacterTies.php" && isRead ? 60000 : 0;
    if (!isRead) {
        // Ook omgekeerde relaties en personeelswijzigingen kunnen andere kaarten raken.
        aetherInvalidateReadRequests();
        try { return await aetherRequestJson(endpoint, options); }
        finally { aetherInvalidateReadRequests(); }
    }
    if (!ttl) return aetherRequestJson(endpoint, options);

    const key = JSON.stringify([endpoint, method, aetherStableJson(options.body ?? null), aetherStableJson(options.headers || {})]);
    let entry = aetherReadRequests.get(key);
    if (options.refresh || (entry && entry.expires <= Date.now())) {
        aetherReadRequests.delete(key);
        entry = null;
    }
    if (!entry) {
        if (aetherReadRequests.size >= 100) aetherReadRequests.delete(aetherReadRequests.keys().next().value);
        entry = { expires: Infinity, promise: null };
        entry.promise = aetherRequestJson(endpoint, options).then((data) => {
            entry.expires = Date.now() + ttl;
            if (data === null && aetherReadRequests.get(key) === entry) aetherReadRequests.delete(key);
            return data;
        }).catch((error) => {
            if (aetherReadRequests.get(key) === entry) aetherReadRequests.delete(key);
            throw error;
        });
        aetherReadRequests.set(key, entry);
    }
    const data = await entry.promise;
    // Een component mag het gedeelde antwoord niet wijzigen voor andere componenten.
    return data === null ? null : JSON.parse(JSON.stringify(data));
}

// Globale plaats om basis-userinfo op te slaan (optioneel bruikbaar in andere files)
window.AETHER_CURRENT_USER = null;
window.AETHER_CSRF_TOKEN = null;

let aetherCurrentUserRequest = null;
function aetherGetCurrentUser() {
    if (window.AETHER_CURRENT_USER) return Promise.resolve(window.AETHER_CURRENT_USER);
    if (!aetherCurrentUserRequest) {
        aetherCurrentUserRequest = apiFetchJson("checkLogin.php").then((data) => {
            if (data?.status !== "ok" || !data.user) {
                throw Object.assign(new Error("Geen geldige sessie."), { status: 401 });
            }
            const user = { ...data.user, csrfToken: data.csrfToken };
            window.AETHER_CURRENT_USER = user;
            return user;
        }).catch((error) => {
            aetherCurrentUserRequest = null;
            throw error;
        });
    }
    return aetherCurrentUserRequest;
}

function userHasPrivilegedRole(user) {
    const role = user?.role || "";
    return role === "administrator" || role === "director";
}

function aetherStableJson(value) {
    if (Array.isArray(value)) return value.map(aetherStableJson);
    if (value && typeof value === "object") {
        return Object.keys(value).sort().reduce((result, key) => {
            result[key] = aetherStableJson(value[key]);
            return result;
        }, {});
    }
    return value;
}

function aetherCreateRequestId() {
    if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID();
    const bytes = new Uint8Array(16);
    globalThis.crypto.getRandomValues(bytes);
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    return Array.from(bytes, (byte, index) =>
        ([4, 6, 8, 10].includes(index) ? "-" : "") + byte.toString(16).padStart(2, "0")
    ).join("");
}

const aetherFinancialRequestMemory = new Map();

function aetherFinancialStorageKey(endpoint, body) {
    return "aether:financial-request:" + endpoint + ":" + JSON.stringify(aetherStableJson(body));
}

function aetherReadPendingFinancialRequest(storageKey) {
    try {
        return sessionStorage.getItem(storageKey) || aetherFinancialRequestMemory.get(storageKey) || null;
    } catch (error) {
        return aetherFinancialRequestMemory.get(storageKey) || null;
    }
}

function aetherStorePendingFinancialRequest(storageKey, requestId) {
    aetherFinancialRequestMemory.set(storageKey, requestId);
    try { sessionStorage.setItem(storageKey, requestId); } catch (error) { /* geheugenfallback */ }
}

function aetherClearPendingFinancialRequest(storageKey) {
    aetherFinancialRequestMemory.delete(storageKey);
    try { sessionStorage.removeItem(storageKey); } catch (error) { /* geheugenfallback */ }
}

async function apiFetchIdempotentJson(endpoint, options = {}) {
    const body = options.body ?? null;
    const storageKey = aetherFinancialStorageKey(endpoint, body);
    const requestId = aetherReadPendingFinancialRequest(storageKey) || aetherCreateRequestId();
    aetherStorePendingFinancialRequest(storageKey, requestId);
    try {
        const result = await apiFetchJson(endpoint, {
            ...options,
            headers: {
                ...(options.headers || {}),
                "Idempotency-Key": requestId
            }
        });
        aetherClearPendingFinancialRequest(storageKey);
        return result;
    } catch (error) {
        if (Number.isInteger(error?.status) && error.status < 500) {
            aetherClearPendingFinancialRequest(storageKey);
        }
        throw error;
    }
}

// Tijdelijke compatibiliteitsnaam voor de al gemigreerde financiële routes.
async function apiFetchFinancialJson(endpoint, options = {}) {
    return apiFetchIdempotentJson(endpoint, options);
}

function syncPrivilegedNavbar(user) {
    document.getElementById("navbarAdminItem")?.classList.toggle("d-none", !userHasPrivilegedRole(user));
}

// Login-check bij laden van de pagina
async function checkLoginOnLoad() {
    try {
        const user = await aetherGetCurrentUser();

        const navbarName = document.getElementById("navbarName");
        if (navbarName) {
            navbarName.textContent = "Welkom " + user.displayName;
        }

        syncPrivilegedNavbar(user);
    } catch (error) {
        console.error("Fout bij sessiecontrole:", error);
        window.location.href = "../../../index.php";
    }
}

window.addEventListener("load", checkLoginOnLoad);

// --------------------------------------
//  HULPFUNCTIES VOOR FORMULIEREN / UI
// --------------------------------------

// Selecteer een optie in een <select> op basis van de value
function activateSelectOption(dropdownMenuId, activeValue) {
    const dropdown = document.getElementById(dropdownMenuId);
    if (!dropdown) return;

    for (let i = 0; i < dropdown.options.length; i++) {
        if (dropdown.options[i].value === activeValue) {
            dropdown.selectedIndex = i;
            break;
        }
    }
}

// Dropdown + input component (voor bv. deelnemerslijst)
// Gebruikt in zowel characters als events
class DropdownInput {
    constructor(containerId, optionsArray, onSelect, startId = null) {
        this.container = document.getElementById(containerId);
        if (!this.container) {
            console.warn(`DropdownInput: container #${containerId} niet gevonden.`);
            return;
        }

        this.options = optionsArray || [];
        this.onSelect = onSelect; // callback functie
        this.startId = startId;

        this.inputId = `${containerId}-input`;
        this.buttonId = `${containerId}-toggle`;
        this.dropdownId = `${containerId}-dropdown`;

        this.render();
        this.setupEvents();

        if (this.startId) {
            this.selectById(this.startId);
        }
    }

    render() {
        this.container.classList.add("dropdown-container");
        this.container.innerHTML = `
          <div class="input-group" id="${this.container.id}-group">
              <button type="button" class="btn btn-outline-secondary" id="${this.container.id}-clear">
                  <i class="fa-solid fa-xmark text-light"></i>
              </button>
              <input id="${this.inputId}" type="text" class="form-control" aria-label="Text input with dropdown">
              <button type="button" class="btn btn-outline-secondary" id="${this.container.id}-reset">
                  <i class="fa-solid fa-trash text-light"></i>
              </button>
              <button type="button" class="btn btn-outline-secondary dropdown-toggle dropdown-toggle-split" id="${this.buttonId}">
                  <span class="visually-hidden">Toggle Dropdown</span>
              </button>
          </div>
          <ul class="dropdown-menu" id="${this.dropdownId}">
              ${this.options
                  .map(opt => `<li><a class="dropdown-item" href="#" data-id="${opt.id}">${opt.text}</a></li>`)
                  .join("")}
          </ul>
      `;

        this.input = document.getElementById(this.inputId);
        this.button = document.getElementById(this.buttonId);
        this.dropdown = document.getElementById(this.dropdownId);
        this.items = Array.from(this.dropdown.querySelectorAll(".dropdown-item"));
        this.clearBtn = document.getElementById(`${this.container.id}-clear`);
        this.resetBtn = document.getElementById(`${this.container.id}-reset`);
    }

    setupEvents() {
        if (!this.input) return;

        this.input.addEventListener("input", () => this.filterOptions());
        this.input.addEventListener("focus", () => this.filterOptions());

        if (this.button) {
            this.button.addEventListener("click", () => {
                this.dropdown.classList.toggle("show");
            });
        }

        this.items.forEach(item => {
            item.addEventListener("click", e => {
                e.preventDefault();
                this.input.value = item.textContent;
                this.dropdown.classList.remove("show");
                this.updateIcons();

                const selectedId = item.dataset.id;
                if (this.onSelect && typeof this.onSelect === "function") {
                    this.onSelect(selectedId);
                }
            });
        });

        if (this.clearBtn) {
            this.clearBtn.addEventListener("click", () => {
                this.input.value = "";
                this.filterOptions();
            });
        }

        this.resetBtn.addEventListener('click', () => {
            this.input.value = '';
            this.filterOptions();

            // Deelnemer loskoppelen (bv. character zonder speler)
            if (this.onSelect && typeof this.onSelect === 'function') {
            this.onSelect(null); // speciale waarde voor "unlink"
            }
        });


        document.addEventListener("click", e => {
            if (!this.container.contains(e.target)) {
                this.dropdown.classList.remove("show");
            }
        });
    }

    updateIcons() {
        if (!this.input || !this.clearBtn || !this.resetBtn) return;

        const inputVal = this.input.value.trim();
        const xIcon = this.clearBtn.querySelector("i");
        const trashIcon = this.resetBtn.querySelector("i");

        const visibleItems = this.items.filter(i =>
            i.textContent.toLowerCase().includes(inputVal.toLowerCase())
        );

        if (inputVal === "") {
            xIcon.className = "fa-solid fa-xmark text-light";
            trashIcon.className = "fa-solid fa-trash text-light";
        } else if (
            visibleItems.length === 1 &&
            visibleItems[0].textContent.toLowerCase() === inputVal.toLowerCase()
        ) {
            xIcon.className = "fa-solid fa-check text-success";
            trashIcon.className = "fa-solid fa-trash text-secondary";
        } else {
            xIcon.className = "fa-solid fa-xmark text-danger";
            trashIcon.className = "fa-solid fa-trash text-secondary";
        }
    }

    filterOptions() {
        const query = this.input.value.toLowerCase();
        let visibleItems = 0;

        this.items.forEach(item => {
            const text = item.textContent.toLowerCase();
            const match = text.includes(query);
            item.style.display = match ? "block" : "none";
            if (match) visibleItems++;
        });

        if (query && visibleItems === 1) {
            const matchedItem = this.items.find(i => i.style.display === "block");
            if (matchedItem) {
                this.input.value = matchedItem.textContent;
                this.dropdown.classList.remove("show");
                this.updateIcons();

                const selectedId = matchedItem.dataset.id;
                if (this.onSelect && typeof this.onSelect === "function") {
                    this.onSelect(selectedId);
                }

                return;
            }
        }

        this.dropdown.classList.toggle("show", query !== "" && visibleItems > 0);
        this.updateIcons();
    }

    selectById(id) {
    const idStr = String(id);
    const item = this.items.find(i => i.dataset.id === idStr);
    if (item) {
        this.input.value = item.textContent;
        this.dropdown.classList.remove("show");
        this.updateIcons();
        if (this.onSelect && typeof this.onSelect === "function") {
        this.onSelect(id);
        }
    }
    }
}
